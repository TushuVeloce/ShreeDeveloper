import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  template: `<p>Mobile works!</p>`,
  styleUrls: [],
})
export class MobileComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
