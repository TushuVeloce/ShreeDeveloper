import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MobileRoutingModule } from './mobile-routing.module';
import { DemoMobileComponent } from './demo-mobile/demo-mobile.component';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MobileRoutingModule
  ]
})
export class MobileModule { }
