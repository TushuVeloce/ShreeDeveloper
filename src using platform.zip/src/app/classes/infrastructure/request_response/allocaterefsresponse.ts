export interface AllocateRefsResponse
{
    Refs: number[];
}
