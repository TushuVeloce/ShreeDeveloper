export class UserLoginRequest
{
    public UserId: string = '';
    public Password: string = '';
    public UserToken: string = '';
    public LoginDeviceId: string = '';
}
