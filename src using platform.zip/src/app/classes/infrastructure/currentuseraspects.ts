export class CurrentUserAspects
{
    public static SystemUserRef: number = 0;
    public static SystemUserRoleRef: number = 0;
}