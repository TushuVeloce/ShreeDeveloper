export const environment = {
  production: true,
  platform: 'web',
};
