export class SystemUserPasswordResetRequest
{
    EMailId: string = '';
    NewPassword: string = '';
}