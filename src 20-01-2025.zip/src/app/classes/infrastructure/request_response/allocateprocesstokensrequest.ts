export interface AllocateProcessTokensRequest
{
    Count: number;
}
