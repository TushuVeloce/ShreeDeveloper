export interface AllocateRefsRequest
{
    Count: number;
}
