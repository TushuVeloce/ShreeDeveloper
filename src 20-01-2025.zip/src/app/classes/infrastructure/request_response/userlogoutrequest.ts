export class UserLogoutRequest
{
    public LoginToken: string = '';
}
