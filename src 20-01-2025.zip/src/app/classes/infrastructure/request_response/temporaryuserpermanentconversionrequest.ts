export class TemporaryUserPermanentConversionRequest
{
    TemporaryUserName: string = '';
    MotherName: string = '';
    MobileNo: string = '';
    EMailId: string = '';
    AadharNo: string = '';
    DateOfBirth: string = '';
    NewPassword: string = '';
}