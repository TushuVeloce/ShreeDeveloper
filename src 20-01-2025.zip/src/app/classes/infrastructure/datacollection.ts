export interface DataCollection
{
    Name: string;
    ColumnDefinitions?: Object;
    Entries: Object[];
}
