import { DataCollection } from './datacollection';

export class DataContainer
{
    public UpdatedTableNames: string[] = <string[]>[];
    public Collections: DataCollection[] = <DataCollection[]>[];
}
