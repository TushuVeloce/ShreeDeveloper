export interface TransactionResult {
  Successful: boolean;
  Message: string;
  Tag?: any;
  TagType?: string;
  ProcessToken?: string;
}
