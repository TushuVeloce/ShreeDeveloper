import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-mobile',
  templateUrl: './demo-mobile.component.html',
  styleUrls: ['./demo-mobile.component.scss'],
})
export class DemoMobileComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
