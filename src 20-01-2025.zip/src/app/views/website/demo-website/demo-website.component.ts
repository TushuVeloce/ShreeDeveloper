import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-website',
  templateUrl: './demo-website.component.html',
  styleUrls: ['./demo-website.component.scss'],
})
export class DemoWebsiteComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
