// export class AppRouteState<T>
// {
//   public Data: T = null!;
//   public LoginToken: string = '';
// }


export class AppRouteState
{
  public Data: any;
  public LoginToken: string = '';
}
